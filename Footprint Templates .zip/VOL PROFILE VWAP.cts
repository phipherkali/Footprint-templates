{
  "Value": {
    "$type": "OFT.Platform.Settings.Charting.ChartSettings, OFT.Platform",
    "ScaleByLowerValue": false,
    "ChartTraderIsEnabled": false,
    "SelectedAccount": "",
    "UseLocalVolumes": false,
    "TIF": 0,
    "TemplateType": "snapshot",
    "IsContinious": false,
    "PanelsIsHidden": false,
    "DrawingObjectses": [],
    "EndDate": "0001-01-01T00:00:00",
    "Template": {
      "TemplateType": "template",
      "ScaleByLowerValue": false,
      "ChartScale": 1,
      "Panels": [
        {
          "IsNew": true,
          "SerializedIndicators": [
            "{\r\n  \"Type\": \"ATAS.Indicators.Technical.ClusterStatistic, ATAS.Indicators.Technical, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7\",\r\n  \"Settings\": \"{\\r\\n  \\\"RowsOrder\\\": {\\r\\n    \\\"Ask\\\": {\\r\\n      \\\"Order\\\": 0,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Bid\\\": {\\r\\n      \\\"Order\\\": 1,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Delta\\\": {\\r\\n      \\\"Order\\\": 2,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"DeltaVolume\\\": {\\r\\n      \\\"Order\\\": 3,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"SessionDelta\\\": {\\r\\n      \\\"Order\\\": 4,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"SessionDeltaVolume\\\": {\\r\\n      \\\"Order\\\": 5,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"MaxDelta\\\": {\\r\\n      \\\"Order\\\": 6,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"MinDelta\\\": {\\r\\n      \\\"Order\\\": 7,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"DeltaChange\\\": {\\r\\n      \\\"Order\\\": 8,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Volume\\\": {\\r\\n      \\\"Order\\\": 9,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"VolumeSecond\\\": {\\r\\n      \\\"Order\\\": 10,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"SessionVolume\\\": {\\r\\n      \\\"Order\\\": 11,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Trades\\\": {\\r\\n      \\\"Order\\\": 12,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Height\\\": {\\r\\n      \\\"Order\\\": 13,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Time\\\": {\\r\\n      \\\"Order\\\": 14,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Duration\\\": {\\r\\n      \\\"Order\\\": 15,\\r\\n      \\\"Enabled\\\": false\\r\\n    }\\r\\n  },\\r\\n  \\\"ShowAsk\\\": false,\\r\\n  \\\"ShowBid\\\": false,\\r\\n  \\\"ShowDelta\\\": true,\\r\\n  \\\"ShowDeltaPerVolume\\\": false,\\r\\n  \\\"ShowSessionDelta\\\": true,\\r\\n  \\\"ShowSessionDeltaPerVolume\\\": false,\\r\\n  \\\"ShowMaximumDelta\\\": false,\\r\\n  \\\"ShowMinimumDelta\\\": false,\\r\\n  \\\"ShowDeltaChange\\\": false,\\r\\n  \\\"ShowVolume\\\": true,\\r\\n  \\\"ShowVolumePerSecond\\\": false,\\r\\n  \\\"ShowSessionVolume\\\": false,\\r\\n  \\\"ShowTicks\\\": false,\\r\\n  \\\"ShowHighLow\\\": false,\\r\\n  \\\"ShowTime\\\": false,\\r\\n  \\\"ShowDuration\\\": false,\\r\\n  \\\"BackGroundColor\\\": \\\"#800F141C\\\",\\r\\n  \\\"BgTransparency\\\": 10,\\r\\n  \\\"GridColor\\\": \\\"#FF21252F\\\",\\r\\n  \\\"VisibleProportion\\\": true,\\r\\n  \\\"VolumeColor\\\": \\\"#FF434651\\\",\\r\\n  \\\"AskColor\\\": \\\"#FF2962FF\\\",\\r\\n  \\\"BidColor\\\": \\\"#FFF71427\\\",\\r\\n  \\\"TextColor\\\": \\\"#FFFFFFFF\\\",\\r\\n  \\\"Font\\\": {\\r\\n    \\\"Size\\\": 9,\\r\\n    \\\"FontFamily\\\": \\\"Arial\\\",\\r\\n    \\\"Bold\\\": false,\\r\\n    \\\"Italic\\\": false,\\r\\n    \\\"Underline\\\": false,\\r\\n    \\\"Strikeout\\\": false\\r\\n  },\\r\\n  \\\"CenterAlign\\\": true,\\r\\n  \\\"HeaderBackground\\\": \\\"#FF787B86\\\",\\r\\n  \\\"HideRowsDescription\\\": false,\\r\\n  \\\"UseVolumeAlert\\\": false,\\r\\n  \\\"VolumeAlertValue\\\": 0.0,\\r\\n  \\\"VolumeAlertFile\\\": \\\"alert1\\\",\\r\\n  \\\"UseDeltaAlert\\\": true,\\r\\n  \\\"DeltaAlertValue\\\": 5.0,\\r\\n  \\\"DeltaAlertFile\\\": \\\"alert1\\\",\\r\\n  \\\"FullScreenMode\\\": false,\\r\\n  \\\"DenyToChangePanel\\\": true,\\r\\n  \\\"ShowDescription\\\": false,\\r\\n  \\\"MarketTime\\\": \\\"2025-11-28T08:14:18.2585838\\\",\\r\\n  \\\"UtcTime\\\": \\\"2025-11-28T08:14:18.2647144Z\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Statistic\\\",\\r\\n  \\\"Panel\\\": \\\"1\\\",\\r\\n  \\\"IsVerticalIndicator\\\": false,\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"Locked\\\": false,\\r\\n  \\\"AllowedInteraction\\\": true\\r\\n}\",\r\n  \"SourceType\": \"bars\",\r\n  \"SourceSeriesId\": 0,\r\n  \"DataSeries\": [\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FFFF5252\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"ClusterStatisticDefaultDataSeries\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Statistic\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    }\r\n  ],\r\n  \"LineSeries\": [],\r\n  \"ShowDescription\": false\r\n}"
          ],
          "Height": 60,
          "Collapsed": false
        },
        {
          "IsNew": false,
          "OldSettings": {
            "$type": "Advanced_Time_And_Sales.Indicators.IndicatorsParameters.MarketProfiliesSettings, OFT.Controls",
            "Merges": {},
            "_maxLevelColor": "255, 255, 255",
            "_valueAreaColor": "Gray",
            "gridColor": "50, 128, 128, 128",
            "_color": "173, 216, 230",
            "_areaColor": "0, 255, 255, 255",
            "_textcolor": "178, 181, 190",
            "_linesColor": "255, 255, 0",
            "PanelN": 0,
            "Height": 60,
            "_showLegend": true,
            "IsSupportedRussianMarket": true,
            "IsSupportedAmericanMarket": true,
            "TPOMode": "volumeProfile",
            "Period": "daily",
            "BeginTimeFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": "00:00:00"
            },
            "BeginTime": "00:00:00",
            "EndTimeFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": "00:00:00"
            },
            "EndTime": "00:00:00",
            "ExtendLinesTillStartOfNextProfile": false,
            "ShowLabelsOfFinishedLines": false,
            "AreaColor": "#00FFFFFF",
            "OnTop": false,
            "Type": "volume",
            "LeftToRight": true,
            "ExtendLines": false,
            "AutoProportion": false,
            "CustomProportionFilter": {
              "EnabledVisible": false,
              "Enabled": true,
              "Value": 0
            },
            "CustomProportion": 0,
            "Color": "#FFADD8E6",
            "BidColor": "#80FF5252",
            "AskColor": "#802196F3",
            "ShowValues": false,
            "ValuesColor": "#FFB2B5BE",
            "VisualizationMode": "solid",
            "Gradient": false,
            "GradientFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": false
            },
            "ShowMaximumLevel": true,
            "MaxLeveltype": "volume",
            "ExtendMaximumLevel": false,
            "ExtendMaximumLevelFilter": {
              "EnabledVisible": false,
              "Enabled": true,
              "Value": false
            },
            "LinesColor": "#FFFFFF00",
            "MaxLevelOpacility": 0,
            "MaxLevelColor": "#FFFFFFFF",
            "ShowMaxLevelValue": false,
            "ShowMaxLevelDate": false,
            "MaxLevelDescription": "",
            "ShowValueArea": true,
            "ExtendValueArea": true,
            "ExtendValueAreaFilter": {
              "EnabledVisible": false,
              "Enabled": true,
              "Value": true
            },
            "ValueAreaVisualType": "area",
            "ValueAreaColor": "#FF0000FF",
            "ValueAreaColorFilter": {
              "EnabledVisible": false,
              "Enabled": true,
              "Value": "#FF0000FF"
            },
            "ValueAreaOpacility": 9,
            "ValueAreTextColor": "#FFFFFFFF",
            "ValueAreTextColorFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": "#FFFFFFFF"
            },
            "VAHDescription": "VAH",
            "VAHDescriptionFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": "VAH"
            },
            "VALDescription": "VAL",
            "VALDescriptionFilter": {
              "EnabledVisible": false,
              "Enabled": false,
              "Value": "VAL"
            },
            "TPOChars": "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
            "Scale": 1,
            "MarkerLetters": "#FF808080",
            "TPOColorMode": "eachDifferent",
            "Colors": [
              "#FFFF0100",
              "#FFFE1600",
              "#FFFE2B00",
              "#FFFE4101",
              "#FFFE5500",
              "#FFFE6A00",
              "#FFFE7E00",
              "#FFFE9400",
              "#FFFEA900",
              "#FFFDBE00",
              "#FFFCCD01",
              "#FFF7D100",
              "#FFF4D701",
              "#FFEFDD00",
              "#FFEEE200",
              "#FFE9E700",
              "#FFDFEE01",
              "#FFE0F200",
              "#FFFFF700",
              "#FFD9FC00",
              "#FFD0FE05",
              "#FFC4FE0B",
              "#FFB9FE10",
              "#FFADFE19",
              "#FFA2FE1F",
              "#FF96FE23",
              "#FF8CFE2C",
              "#FF81FE31",
              "#FF75FD37",
              "#FF69FE40",
              "#FF5EFA4E",
              "#FF53F65B",
              "#FF48F46C",
              "#FF3BF17A",
              "#FF31EE87",
              "#FF26EA96",
              "#FF1AE7A4",
              "#FF10E4B2",
              "#FF04E1C0",
              "#FF00D2CA",
              "#FF00BBD0",
              "#FF00A4D6",
              "#FF008DDC",
              "#FF0076E1",
              "#FF005FE7",
              "#FF0048ED",
              "#FF0031F3",
              "#FF001AF9"
            ],
            "MinimumLitterWidth": 10,
            "DrawingMode": "auto",
            "BlockTextColor": "#FF000000",
            "TimePeriod": 30,
            "SplitPeriods": false,
            "HighlightEveryOpen": false,
            "HighlightColor": "#FFFF0000",
            "HighlightEveryClose": false,
            "HighlightCloseColor": "#FFFF0000",
            "ShowTPOPoc": true,
            "TPOPocColor": "#FF787B86",
            "ExtendTPOPoc": false,
            "TPOPOCTextColor": "#FFFFFFFF",
            "TPOPOCDescription": "TPO POC",
            "ValueAreaVisualMode": "lines",
            "TPOVAColor": "#FF787B86",
            "ExtendTPOValueArea": false,
            "TPOValueAreTextColor": "#FFFFFFFF",
            "TPOVAHDescription": "TPO VAH",
            "TPOVALDescription": "TPO VAL",
            "ShowSinglePrints": true,
            "ExtendSinglePrints": false,
            "SinglePrintsColor": "#FFADD8E6",
            "TPOSinglePrintsTextColor": "#FF000000",
            "ShowInitialBalance": false,
            "InitialBalanceStartPeriod": 1,
            "InitialBalanceRange": 2,
            "InitialBalanceColor": "#FFFF9800",
            "InitialBalanceWidth": 5,
            "CandleMode": "none",
            "CandleWidth": 16,
            "Border": "#FF808080",
            "BorderWidth": 3,
            "UpCandleColor": "#FF4CAF50",
            "DnCandleColor": "#FFFF5252",
            "ShowGrid": false,
            "GridColor": "#32808080",
            "ShowCumulativeVaues": true,
            "CumulativeVauesLocation": "hide",
            "SummaryTextColor": "#FF787B86",
            "UseFilter": false,
            "MinFilter": 0.0,
            "MaxFilter": 0.0,
            "FilterColor": "#FF311B92",
            "FullLine": true,
            "HotKeys": [
              "G"
            ],
            "HotKeyMerge": [
              "Add"
            ],
            "HotKeySplit": [
              "Subtract"
            ],
            "Visible": true
          },
          "SerializedIndicators": [],
          "Height": 60,
          "Collapsed": false
        },
        {
          "IsNew": true,
          "SerializedIndicators": [
            "{\r\n  \"Type\": \"ATAS.Indicators.Technical.VWAP, ATAS.Indicators.Technical, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7\",\r\n  \"Settings\": \"{\\r\\n  \\\"AllowCustomStartPoint\\\": false,\\r\\n  \\\"StartKeyFilter\\\": 49,\\r\\n  \\\"StartKey\\\": \\\"f\\\",\\r\\n  \\\"DeleteKeyFilter\\\": 50,\\r\\n  \\\"DeleteKey\\\": \\\"g\\\",\\r\\n  \\\"SavePointFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": false,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": false\\r\\n  },\\r\\n  \\\"SavePoint\\\": false,\\r\\n  \\\"StartDate\\\": \\\"0001-01-01T00:00:00\\\",\\r\\n  \\\"ResetOnSessionFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": false,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": false\\r\\n  },\\r\\n  \\\"ResetOnSession\\\": false,\\r\\n  \\\"ColoredDirection\\\": false,\\r\\n  \\\"BullishColor\\\": \\\"#FF2196F3\\\",\\r\\n  \\\"BearishColor\\\": \\\"#FFB22222\\\",\\r\\n  \\\"StartBar\\\": 0,\\r\\n  \\\"Type\\\": \\\"weekly\\\",\\r\\n  \\\"TWAPMode\\\": \\\"vwap\\\",\\r\\n  \\\"VolumeMode\\\": \\\"total\\\",\\r\\n  \\\"Period\\\": 300,\\r\\n  \\\"StDev\\\": 1.0,\\r\\n  \\\"StDev1\\\": 2.0,\\r\\n  \\\"StDev2\\\": 3.0,\\r\\n  \\\"CustomSessionStart\\\": \\\"00:00:00\\\",\\r\\n  \\\"CustomSessionEnd\\\": \\\"23:59:59\\\",\\r\\n  \\\"Days\\\": 20,\\r\\n  \\\"ShowFirstPeriod\\\": false,\\r\\n  \\\"VWAPOnly\\\": true,\\r\\n  \\\"FullScreenMode\\\": false,\\r\\n  \\\"DenyToChangePanel\\\": false,\\r\\n  \\\"ShowDescription\\\": true,\\r\\n  \\\"MarketTime\\\": \\\"2025-11-28T08:14:18.4184742\\\",\\r\\n  \\\"UtcTime\\\": \\\"2025-11-28T08:14:18.4187061Z\\\",\\r\\n  \\\"Name\\\": \\\"VWAP/TWAP\\\",\\r\\n  \\\"Panel\\\": \\\"Chart\\\",\\r\\n  \\\"IsVerticalIndicator\\\": false,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"Locked\\\": false,\\r\\n  \\\"AllowedInteraction\\\": false\\r\\n}\",\r\n  \"SourceType\": \"ohlC4\",\r\n  \"SourceSeriesId\": 0,\r\n  \"DataSeries\": [\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"line\\\",\\r\\n  \\\"Color\\\": \\\"#C4008000\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 2,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"VwapTwap\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"VWAP|TWAP\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"BaseLineSettingsDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Lower2\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Lower Deviation 3\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Upper2\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Upper Deviation 3\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Lower1\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Lower Deviation 2\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Upper1\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Upper Deviation 2\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"line\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"dot\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Lower\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Lower Deviation 1\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"line\\\",\\r\\n  \\\"Color\\\": \\\"#FF00BCD4\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"dot\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Upper\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Upper Deviation 1\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FF4CAF50\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 5,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": false,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"PrevPosValueSeries\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Previous upper value\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FFCD5C5C\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 5,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": false,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"PrevNegValueSeries\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Previous lower value\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40C30101\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Upper2Background\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Upper fill 2\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40C30101\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Upper2BackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Upper Fill 2 res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40C30101\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"UpperBackground\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Upper fill\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40C30101\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"UpperBackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Upper Fill res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40808080\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"MidUpBackground\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Middle fill up\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40808080\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"MidUpBackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Middle Fill Up Res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40808080\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"MidDownBackground\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Middle fill down\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#40808080\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"MidDownBackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Middle Fill Down res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#4000FF00\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"LowerBackground\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Lower fill\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#4000FF00\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"LowerBackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Lower Fill res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#4000FF00\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Lower2Background\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Lower fill 2\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    },\r\n    {\r\n      \"Type\": \"ATAS.Indicators.RangeDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"RangeColor\\\": \\\"#4000FF00\\\",\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"Visible\\\": false,\\r\\n  \\\"DrawAbovePrice\\\": false,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"Lower2BackgroundRes\\\",\\r\\n  \\\"Type\\\": \\\"band\\\",\\r\\n  \\\"Name\\\": \\\"Lower Fill 2 res\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    }\r\n  ],\r\n  \"LineSeries\": [],\r\n  \"ShowDescription\": true\r\n}"
          ],
          "Height": 60,
          "Collapsed": false
        }
      ],
      "Indicators": [],
      "clusterSettings": {
        "Caption": "Cluster Settings",
        "Volumes": "#FF2962FF",
        "Bid": "#FFF71427",
        "Ask": "#FF2962FF",
        "ClusterBorderWidth": 1,
        "Foreground": "#FFABAEB8",
        "AutoSize": true,
        "FontSize": 9.0,
        "CutLongText": true,
        "MinimumClusterWidthToShowText": 40,
        "ValueAreaColor": "#64C8D8FF",
        "ShowValueArea": false,
        "ImbalanceBid": "#FFFF0000",
        "ImbalanceAsk": "#C50000FF",
        "MinimumImbalanceDifference": 0,
        "IgnoreZeroValues": true,
        "ImbalanceVolumeFilter": 0,
        "ImbalanceRate": 200,
        "ShowDirectionMarker": false,
        "DirectionMakerWidth": 0,
        "ClusterBorderPen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2A2E39"
        },
        "BorderColorByDirection": false,
        "SecondClusters": {
          "Caption": "",
          "Enabled": true,
          "ClustersContentModeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersContentModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volume",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ClustersContentMode": "volume",
          "ClustersModeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersVisualModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volumeHistogram",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ClustersMode": "volumeHistogram",
          "UseBorderOfEachPriceLevelFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": false
          },
          "UseBorderOfEachPriceLevel": false,
          "ColorSchemeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersColorSchemes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volumeProportion",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ColorScheme": "volumeProportion",
          "ClusterBGFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#00FFFFFF"
          },
          "ClusterBG": "#00FFFFFF",
          "VolumeColor": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#FF2962FF"
          },
          "BidColor": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": "#FFFF0000"
          },
          "AskColor": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": "#FF008000"
          },
          "HeatmapType": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 0
          },
          "UpperCutOff": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 20
          },
          "Contrast": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 0
          },
          "MaxVolTypeFilter": {
            "EnumType": "Advanced_Time_And_Sales.ClusterSettings+MaxVolSelectionType, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volume",
            "Enabled": true,
            "EnabledVisible": false
          },
          "MaxVolType": "volume",
          "MaxVolColorFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#00000000"
          },
          "MaxVolColor": "#00000000",
          "MaxVolSelectionWidthFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": 1
          },
          "MaxVolSelectionWidth": 1,
          "MaxVolTextColorFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#FFD1D4DC"
          },
          "MaxVolTextColor": "#FFD1D4DC",
          "MaxLevelBoldFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": true
          },
          "MaxLevelBold": true
        },
        "BorderType": "none",
        "BorderColorByDirectionFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": false
        },
        "ClusterBorderPenFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": {
            "Color": "#FF2A2E39",
            "LineDashStyle": 0,
            "Width": 1
          }
        },
        "ShowDirectionMarkerFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": 0
        },
        "Showtext": true,
        "ForegroundFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFABAEB8"
        },
        "AutoSizeFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "FontSizeFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 9.0
        },
        "Divider": 1.0,
        "CutLongTextFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "MinimumClusterWidthToShowTextFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 40
        },
        "ValueAreaColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#64C8D8FF"
        },
        "ProportionalMode": "bar",
        "ProportionByAllBars": false,
        "GradientRate": 100,
        "CustomProportionValue": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 0.0
        },
        "CustomproportionVolume": 0.0,
        "UpperCutOffGradient": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 0
        },
        "EnableBidAskImbalance": true,
        "ImbalanceBidFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFFF0000"
        },
        "ImbalanceAskFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#C50000FF"
        },
        "ImbalanceRateFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 200
        },
        "ImbalanceVolumeFilterInt": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 0
        },
        "MinimumImbalanceDifferenceFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 0
        },
        "IgnoreZeroValuesFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "BoldFontForImbalances": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "CustomRowHeight": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": 16
        },
        "Filters": [],
        "ClustersContentModeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersContentModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "delta",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ClustersContentMode": "delta",
        "ClustersModeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersVisualModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "deltaHistogram",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ClustersMode": "deltaHistogram",
        "UseBorderOfEachPriceLevelFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": false
        },
        "UseBorderOfEachPriceLevel": false,
        "ColorSchemeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersColorSchemes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "heatMapDelta",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ColorScheme": "heatMapDelta",
        "ClusterBGFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#00FFFFFF"
        },
        "ClusterBG": "#00FFFFFF",
        "VolumeColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FF2962FF"
        },
        "BidColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FFF71427"
        },
        "AskColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FF2962FF"
        },
        "HeatmapType": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 10
        },
        "UpperCutOff": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 25
        },
        "Contrast": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 10
        },
        "MaxVolTypeFilter": {
          "EnumType": "Advanced_Time_And_Sales.ClusterSettings+MaxVolSelectionType, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "volume",
          "Enabled": true,
          "EnabledVisible": false
        },
        "MaxVolType": "volume",
        "MaxVolColorFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFFFFFFF"
        },
        "MaxVolColor": "#FFFFFFFF",
        "MaxVolSelectionWidthFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 1
        },
        "MaxVolSelectionWidth": 1,
        "MaxVolTextColorFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFD1D4DC"
        },
        "MaxVolTextColor": "#FFD1D4DC",
        "MaxLevelBoldFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "MaxLevelBold": true
      },
      "colorsettings": {
        "BuyCandlePricePen": {
          "Color": "0, 255, 255, 255",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "SellCandlePricePen": {
          "Color": "0, 255, 255, 255",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "BuyBarPricePen": {
          "Color": "8, 153, 129",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "SellBarPricePen": {
          "Color": "242, 56, 90",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "DojiBarPricePen": {
          "Color": "125, 125, 125",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "LineChartPricePen": {
          "Color": "41, 98, 255",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "MountainChartPricePen": {
          "Color": "71, 107, 150",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "SolidCurrentPricePen": {
          "Color": "89, 89, 89",
          "DashStyle": "solid",
          "Width": 2.0
        },
        "Caption": "Chart Color Settings",
        "BackgroundBrushSettings": {
          "UseEndColor": false,
          "StartColor": "#FF0F141C",
          "EndColor": "#FFADD8E6"
        },
        "BackGround": "#FF0F141C",
        "OhlcColor": {
          "EnabledVisible": true,
          "Enabled": true,
          "Value": "#FFABAEB8"
        },
        "StateColor": "#FFABAEB8",
        "TextHistogramColor": "#FFB2B5BE",
        "LabelsBackgroundColor": "#00000000",
        "IndicatorsSeparator": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF434651"
        },
        "CurrentPriceColor": {
          "EnabledVisible": true,
          "Enabled": true,
          "Value": "#FF595959"
        },
        "PriceLinePen": {
          "LineDashStyle": "dash",
          "Width": 1,
          "Color": "#FFEF5350"
        },
        "PriceLineDashStyle": "solid",
        "PriceLineWidth": 2,
        "ExtendPriceLine": false,
        "CrosshairPen": {
          "LineDashStyle": "dash",
          "Width": 1,
          "Color": "#FF9598A1"
        },
        "AVersion": 1,
        "AxisCurrentBackColor": "#FF363A45",
        "AxisCurrentForeColor": "#FFF1F1F1",
        "GridPen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF21252F"
        },
        "ShowVHorizontalGrid": true,
        "CustomGridStep": 0,
        "ShowVericalGrid": false,
        "CustomVertGridStep": 0,
        "NewSessionPen": {
          "LineDashStyle": "dot",
          "Width": 1,
          "Color": "#00FFFFFF"
        },
        "AxisColorFilter": {
          "EnabledVisible": true,
          "Enabled": true,
          "Value": "#FF151B26"
        },
        "AxisColor": "#FF151B26",
        "AxisTextColor": "#FFABAEB8",
        "FontSizeDecimal": 10.0,
        "TimeFormat": "auto",
        "HidePriceAxis": false,
        "DrawAxisBorders": true,
        "BuyColor": "#00FFFFFF",
        "SellColor": "#00FFFFFF",
        "DrawCandleBorder": false,
        "CandleBorderColorAsBody": true,
        "CellBorderColor": "#FF7D7D7D",
        "CandleBorderWidth": 1,
        "BarsWidth": 1,
        "DojiBarColor": "#FF7D7D7D",
        "DownBarColor": "#FFF2385A",
        "UpBarColor": "#FF089981",
        "ShowOpenOfBar": true,
        "ShowCloseOfBar": true,
        "ChartLinePen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2962FF"
        },
        "MountainLinePen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2962FF"
        },
        "MountainBrushSettings": {
          "UseEndColor": true,
          "StartColor": "#B62962FF",
          "EndColor": "#062962FF"
        },
        "UseSessionTime": false,
        "SessionStartFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "00:00:00"
        },
        "SessionStart": "00:00:00",
        "SessionEndFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "23:59:59"
        },
        "SessionEnd": "23:59:59",
        "PriceBorder": false,
        "ShowIndicatorsValuesOnMouseOver": true,
        "AutoTransFormCandles": true,
        "CandleSizeTotransformToClusters": 20,
        "HideClustersPanel": true,
        "AutoTransformHorizontalLines": false,
        "AutoTransformVerticalLines": false,
        "PriceOffset": 80,
        "ChartOffset": 30,
        "UseSmoothing": true,
        "MouseWheelBehavior": "zoom",
        "LeaveRulerOnMouseRelease": false,
        "ShowIndicatorsList": true,
        "MinimizeValues": true,
        "DigitsAfterComma": 0,
        "VolumesInUSDTFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": false
        },
        "VolumesInUSD": false,
        "KeepSelectedObjects": false,
        "ObjectsSelectionDrawingColor": "30, 83, 228",
        "ObjectsSelectionColor": "#FF1E53E4",
        "Sensitivity": 0,
        "UseOptimizationMode": false,
        "UseCustomUpdateIntervals": false,
        "CustomFPS": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": {
            "Start": 10,
            "End": 50
          }
        },
        "IsChartInstrumentCrypto": true,
        "IndicatorsListIsCollapsed": true,
        "VolumeValuesFormat": "{0:0.}",
        "RedrawInterval": 100,
        "NewSessionLineColor": "#00FFFFFF",
        "Сl_crosshair": "#FF9598A1",
        "GridColor": "#FF21252F",
        "HistogramLinesColor": "#C8ADD8E6",
        "HistogramColor": "#FF808080",
        "ShowCumulativeValues": true,
        "BidColor": "#FFE84548",
        "AskColor": "#FF49D149",
        "ValueAreaColor": "#FFC8D8FF",
        "PocColor": "#FFC8D8FF",
        "HistogramTextColor": "#FF35212E",
        "ExtendPoc": false,
        "ExtendValueArea": false
      },
      "histogramInterval": "contract",
      "typeHistogram": "bidAsk",
      "ShowHistogram": false,
      "ShowingDigital": false,
      "UseOpacility": false,
      "ShowTxtMouse": true,
      "VisibleCrossHair": true,
      "ShowValueArea": true,
      "ShowPoc": true,
      "AlwaysOnTop": false,
      "BarsType": "candles",
      "ClusterWidth": 5.1730330855434628455442438438,
      "TypeCluster": "volume",
      "PaintingMode": "drawCrossHair",
      "TradingSettings": {
        "PnLMode": "money",
        "Caption": "",
        "ShowText": true,
        "OneClickMode": false,
        "TradingMode": "autoDetection",
        "StopMode": "stop",
        "Slippage": 5,
        "ShowTrades": "visible",
        "Size": 6,
        "TradesColor": "#FF2962FF",
        "TradesSellColor": "#FF2962FF",
        "ShowOrders": "visible",
        "OrdersOffset": 115,
        "BuyOrdersColors": "#FF089981",
        "SellOrdersColor": "#FFF2385A",
        "LimitColors": "#FF089981",
        "StopColor": "#FFF2385A",
        "OrderstextColor": "#FFD1D4DC",
        "ShowPosition": "visible",
        "PositionOffset": 115,
        "PositionTextColors": "#FFF1F1F1",
        "PositionBackGround": "#FF151B26",
        "PositionPositive": "#FF089981",
        "PositionNegative": "#FFF2385A",
        "SkipValidateStrategy": false
      },
      "ClusterVisualizationType": "bidAskLadder",
      "Version": 1,
      "ChangeHeightmanualy": true,
      "RowHeight": 1.047539639474586,
      "UseAutoScale": true,
      "LayoutString": "<XtraSerializer version=\"1.0\" application=\"\">\r\n  <property name=\"#LayoutVersion\">1.4</property>\r\n  <property name=\"$BarManager\" iskey=\"true\" value=\"BarManager\">\r\n    <property name=\"RuntimeCustomizations\" iskey=\"true\" value=\"11\">\r\n      <property name=\"Item1\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126548312</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item2\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126548312</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item3\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564203</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item4\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564203</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item5\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">DrawingObjectsToolbar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564218</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item6\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564218</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item7\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">3014156</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item8\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">3016093</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item9\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">3016093</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item10\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">DrawingObjectsToolbar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">3016093</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item11\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">3016109</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n    </property>\r\n  </property>\r\n  <property name=\"$BarManager$ChartLayoutControl\" iskey=\"true\" value=\"BarManager$ChartLayoutControl\">\r\n    <property name=\"CollapsableContentWidth\">215</property>\r\n  </property>\r\n</XtraSerializer>",
      "FixedProfile": {
        "Clicks": 0,
        "_color": "128, 41, 98, 255",
        "_valueAreaColor": "120, 123, 134",
        "_maxLevelColor": "209, 212, 220",
        "_textcolor": "171, 174, 184",
        "_linesColor": "120, 123, 134",
        "AutoSetSecondPos": false,
        "_pressedElement": "none",
        "Pressed": false,
        "IsObjectInPanel": false,
        "IsUnderCursor": false,
        "PanelID": 0,
        "_lastScale": 200,
        "Width": 1,
        "ShowLabelsOfFinishedLines": false,
        "AreaOpacility": 0,
        "ShowCumulativeVaues": true,
        "IsFixedMode": true,
        "IsAnchored": false,
        "Offset": 0,
        "ProfileWidth": 0,
        "_areaColor": "0, 255, 255, 255",
        "_borderColor": "30, 83, 228",
        "CustomPeriodIsSet": false,
        "TPOMode": "volumeProfile",
        "ProfilePeriod": "currentDay",
        "MarketProfileTimeFrame": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "00:30:00"
        },
        "ProfileLocation": "left",
        "AreaFillColor": "#00FFFFFF",
        "BorderColor": "#FF1E53E4",
        "Type": "volume",
        "ExtendLines": false,
        "ShowValues": true,
        "LeftToRight": true,
        "VisualizationMode": "solid",
        "Gradient": false,
        "GradientFilter": false,
        "WidthFactor": 100,
        "CalculateBasedSelection": false,
        "ProfileColor": "#802962FF",
        "BidColor": "#80F71427",
        "AskColor": "#802962FF",
        "ValuesColor": "#FFABAEB8",
        "ShowMaximumLevel": true,
        "MaxLeveltype": "volume",
        "ExtendMaximumLevel": false,
        "LinesColorFilter": "#FF787B86",
        "LinesColor": "#FF787B86",
        "MaxLevelColorFilter": "#FFD1D4DC",
        "MaxLevelColor": "#FFD1D4DC",
        "ShowMaxLevelValueFilter": false,
        "ShowMaxLevelValue": false,
        "ShowMaxLevelDateFilter": false,
        "ShowMaxLevelDate": false,
        "MaxLevelDescriptionFilter": "vPOC",
        "MaxLevelDescription": "vPOC",
        "ShowValueArea": true,
        "ValueAreaVisualType": "lines",
        "ExtendValueAreaFilter": false,
        "ExtendValueArea": false,
        "ValueAreaColorFilter": "#FF787B86",
        "ValueAreaColor": "#FF787B86",
        "ValueAreTextColorFilter": "#FFD1D4DC",
        "ValueAreTextColor": "#FFD1D4DC",
        "VAHDescriptionFilter": "VAH",
        "VAHDescription": "VAH",
        "VALDescriptionFilter": "VAL",
        "VALDescription": "VAL",
        "ShowDynamicPoc": false,
        "DynamicPocColorFilter": "#FFFF5252",
        "DynamicPocWidthFilter": 3,
        "DynamicPocStyleFilter": {
          "EnumType": "System.Drawing.Drawing2D.DashStyle, System.Drawing.Common, Version=8.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51",
          "Value": "solid",
          "Enabled": false,
          "EnabledVisible": false
        },
        "ShowDynamicPocLabelsFilter": false,
        "DynamicPocTextColorFilter": "#FF363A45",
        "TPOChars": "ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
        "Scale": 1,
        "MarkerLetters": "#FF808080",
        "TPOColorMode": "eachDifferent",
        "Colors": [
          "#FFFF0100",
          "#FFFE1600",
          "#FFFE2B00",
          "#FFFE4101",
          "#FFFE5500",
          "#FFFE6A00",
          "#FFFE7E00",
          "#FFFE9400",
          "#FFFEA900",
          "#FFFDBE00",
          "#FFFCCD01",
          "#FFF7D100",
          "#FFF4D701",
          "#FFEFDD00",
          "#FFEEE200",
          "#FFE9E700",
          "#FFDFEE01",
          "#FFE0F200",
          "#FFFFF700",
          "#FFD9FC00",
          "#FFD0FE05",
          "#FFC4FE0B",
          "#FFB9FE10",
          "#FFADFE19",
          "#FFA2FE1F",
          "#FF96FE23",
          "#FF8CFE2C",
          "#FF81FE31",
          "#FF75FD37",
          "#FF69FE40",
          "#FF5EFA4E",
          "#FF53F65B",
          "#FF48F46C",
          "#FF3BF17A",
          "#FF31EE87",
          "#FF26EA96",
          "#FF1AE7A4",
          "#FF10E4B2",
          "#FF04E1C0"
        ],
        "MinimumLitterWidth": 10,
        "DrawingMode": "auto",
        "BlockTextColor": "#FF000000",
        "TimePeriod": 30,
        "SplitPeriods": false,
        "HighlightColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#FFFF0000"
        },
        "HighlightEveryOpen": false,
        "HighlightColor": "#FFFF0000",
        "HighlightEveryClose": false,
        "HighlightCloseColor": "#FFFF0000",
        "HighlightCloseColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#FFFF0000"
        },
        "ShowTPOPoc": true,
        "TPOPocColorFilter": "#FF787B86",
        "TPOPocColor": "#FF787B86",
        "ExtendTPOPocFilter": false,
        "ExtendTPOPoc": false,
        "TPOPOCTextColorFilter": "#FFD1D4DC",
        "TPOPOCTextColor": "#FFD1D4DC",
        "TPOPOCDescriptionFilter": "TPO POC",
        "TPOPOCDescription": "TPO POC",
        "ValueAreaVisualMode": "lines",
        "TPOVAColorFilter": "#FF787B86",
        "TPOVAColor": "#FF787B86",
        "ExtendTPOValueAreaFilter": false,
        "ExtendTPOValueArea": false,
        "TPOValueAreTextColorFilter": "#FFD1D4DC",
        "TPOValueAreTextColor": "#FFD1D4DC",
        "TPOVAHDescriptionFilter": "TPO VAH",
        "TPOVAHDescription": "TPO VAH",
        "TPOVALDescriptionFilter": "TPO VAL",
        "TPOVALDescription": "TPO VAL",
        "ShowSinglePrints": false,
        "ExtendSinglePrintsFilter": false,
        "ExtendSinglePrints": false,
        "SinglePrintsColorFilter": "#FFADD8E6",
        "SinglePrintsColor": "#FFADD8E6",
        "TPOSinglePrintsTextColorFilter": "#FF000000",
        "TPOSinglePrintsTextColor": "#FF000000",
        "ShowInitialBalance": false,
        "InitialBalanceStartPeriodFilter": 1,
        "InitialBalanceStartPeriod": 1,
        "InitialBalanceRangeFilter": 2,
        "InitialBalanceRange": 2,
        "InitialBalanceColorFilter": "#FFFF9800",
        "InitialBalanceColor": "#FFFF9800",
        "InitialBalanceWidthFilter": 5,
        "InitialBalanceWidth": 5,
        "CandleMode": "none",
        "CandleWidthFilter": 16,
        "CandleWidth": 16,
        "BorderFilter": "#FF808080",
        "Border": "#FF808080",
        "BorderWidthFilter": 3,
        "BorderWidth": 3,
        "UpCandleColorFilter": "#FF089981",
        "UpCandleColor": "#FF089981",
        "DnCandleColorFilter": "#FFF2385A",
        "DnCandleColor": "#FFF2385A",
        "SummaryTextColor": "#FFD1D4DC",
        "CumulativeVauesLocation": "bottomRight",
        "ShowBidAsk": false,
        "ShowHighLowPrices": false,
        "BidSummaryColor": "#FFF2385A",
        "AskSummaryColor": "#FF089981",
        "ValuesSummaryColor": "#FFD1D4DC",
        "UseFilter": false,
        "MinDecimalFilter": 0.0,
        "MinFilter": 0.0,
        "MaxDecimalFilter": 0.0,
        "MaxFilter": 0.0,
        "ColorFilter": "#FF311B92",
        "FilterColor": "#FF311B92",
        "FullLineFilter": false,
        "FullLine": false,
        "UsePocAlert": false,
        "PocAlertFile": "alert1",
        "UsePocTouchAlert": false,
        "RepeatPocTouchAlert": false,
        "PocTouchAlertFile": "alert1",
        "UseValAlert": false,
        "RepeatValAlert": false,
        "ValAlertFile": "alert1",
        "UseVahAlert": false,
        "RepeatVahAlert": false,
        "VahAlertFile": "alert1",
        "AreaColor": "#1A3B3BFE",
        "Color": "#FF3B3BFE",
        "Style": "solid",
        "UseApproximationAlert": false,
        "UseRepetitiveAlertFilter": false,
        "UseRepetitiveAlert": false,
        "FilterApproximation": 3,
        "ApproximationFilter": 3,
        "AlertFileFilter": "alert1",
        "AlertFile": "alert1",
        "ShowAlertIconFilter": true,
        "ShowAlertIcon": true,
        "AlertForeColorFilter": "#FFFFFFFF",
        "AlertForeColor": "#FFFFFFFF",
        "AlertBGColorFilter": "#FF000000",
        "AlertBGColor": "#FF000000",
        "FirstPrice": 4293.0,
        "FirstPos": 0,
        "SecondPrice": 4893.0,
        "SecondPos": 0,
        "_firstTime": "0001-01-01T00:00:00",
        "_secondTime": "0001-01-01T00:00:00",
        "Id": "88f14350-c4d9-4fbf-bfe5-388b07610eed",
        "IsGlobal": false,
        "ShowBelowChart": false,
        "Selected": false,
        "MouseOver": false,
        "InstrumentName": "BTCUSDT@BinanceFutures",
        "InstrumentUniqName": "BTCUSDT",
        "UseTimeAxisDrawing": false,
        "Visible": true,
        "Locked": false
      },
      "Minimum": 86171.04316318628681253385693,
      "Maximum": 97569.17985421283554766997507
    },
    "TimeFrame": {
      "Period": "timeFrame",
      "PeriodParameters": {
        "$type": "OFT.Controls.Chart.MinuteTimeFrame, OFT.Controls",
        "TimeFrame": "h4",
        "CustomTimeFrame": 1,
        "Label": "@value",
        "DefaultDaysToLoad": 30,
        "VisualName": "H4"
      },
      "CustomDaysCount": 30,
      "CustomEndDate": "2025-11-28T08:50:41.7541099+01:00",
      "CustomStartDate": "2025-10-30T08:50:41.7541099+01:00",
      "LoadCustomDateSetting": false,
      "CustomDateSetting": "daysCount",
      "IsHistorical": false
    },
    "Canvas": {
      "Elements": []
    },
    "LinkedPanels": [],
    "Width": 5.1730330855434628455442438438,
    "StrategySettings": [],
    "TraderSettings": {
      "SelectedTIF": "goodTillCancel",
      "SelectedOrderType": "market",
      "Volume": 0.001,
      "ApplyToAllWindow": false,
      "SelectedCurrency": "Lots",
      "IsPercentMode": false,
      "StopPrice": 0.0,
      "StopTriggerPriceType": "last",
      "MarketOrderFlags": {
        "ReduceOnly": false
      },
      "LimitOrderFlags": {
        "ReduceOnly": false
      },
      "ConditionalMarketOrderFlags": {
        "ReduceOnly": false
      },
      "ConditionalLimitOrderFlags": {
        "ReduceOnly": false
      }
    },
    "IsVisibleDrawingObjectsBar": true,
    "TradingSession": {
      "Id": 1
    },
    "TradingIsLocked": false
  },
  "IsSystem": false
}