{
  "Value": {
    "$type": "OFT.Platform.Settings.Charting.ChartSettings, OFT.Platform",
    "ScaleByLowerValue": false,
    "ChartTraderIsEnabled": false,
    "SelectedAccount": "",
    "UseLocalVolumes": false,
    "TIF": 0,
    "TemplateType": "snapshot",
    "IsContinious": false,
    "PanelsIsHidden": false,
    "DrawingObjectses": [],
    "EndDate": "0001-01-01T00:00:00",
    "Template": {
      "TemplateType": "template",
      "ScaleByLowerValue": false,
      "ChartScale": 1,
      "Panels": [
        {
          "IsNew": true,
          "SerializedIndicators": [
            "{\r\n  \"Type\": \"ATAS.Indicators.Technical.ClusterSearch, ATAS.Indicators.Technical, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7\",\r\n  \"Settings\": \"{\\r\\n  \\\"Type\\\": \\\"delta\\\",\\r\\n  \\\"CalcType\\\": \\\"delta\\\",\\r\\n  \\\"AutoFilter\\\": false,\\r\\n  \\\"MinimumFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1000.0\\r\\n  },\\r\\n  \\\"MaximumFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": true,\\r\\n    \\\"Value\\\": -250.0\\r\\n  },\\r\\n  \\\"MinAverageTrade\\\": 0.0,\\r\\n  \\\"MaxAverageTrade\\\": 0.0,\\r\\n  \\\"MinPercent\\\": 0.0,\\r\\n  \\\"MaxPercent\\\": 0.0,\\r\\n  \\\"DeltaImbalance\\\": 0.0,\\r\\n  \\\"DeltaFilter\\\": 0.0,\\r\\n  \\\"CandleDir\\\": \\\"any\\\",\\r\\n  \\\"BarsRange\\\": 1,\\r\\n  \\\"PriceRange\\\": 3,\\r\\n  \\\"PipsFromHigh\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 100000000.0\\r\\n  },\\r\\n  \\\"PipsFromLow\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 100000000.0\\r\\n  },\\r\\n  \\\"PriceLoc\\\": \\\"lowerWick\\\",\\r\\n  \\\"MinCandleHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MaxCandleHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MinCandleBodyHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MaxCandleBodyHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"UseTimeFilter\\\": false,\\r\\n  \\\"TimeFrom\\\": \\\"00:00:00\\\",\\r\\n  \\\"TimeTo\\\": \\\"00:00:00\\\",\\r\\n  \\\"OnlyOneSelectionPerBar\\\": false,\\r\\n  \\\"VisualType\\\": \\\"triangle\\\",\\r\\n  \\\"ClusterColor\\\": \\\"#641EFF00\\\",\\r\\n  \\\"VisualObjectsTransparency\\\": 70,\\r\\n  \\\"ShowPriceSelection\\\": false,\\r\\n  \\\"PriceSelectionColor\\\": \\\"#64FF00FF\\\",\\r\\n  \\\"Transparency\\\": 0,\\r\\n  \\\"FixedSizes\\\": false,\\r\\n  \\\"Size\\\": 15,\\r\\n  \\\"MinSize\\\": 15,\\r\\n  \\\"MaxSize\\\": 50,\\r\\n  \\\"UseAlerts\\\": false,\\r\\n  \\\"AlertFile\\\": \\\"alert2\\\",\\r\\n  \\\"AlertColor\\\": \\\"#FF000000\\\",\\r\\n  \\\"Days\\\": 20,\\r\\n  \\\"UsePrevClose\\\": false,\\r\\n  \\\"FullScreenMode\\\": false,\\r\\n  \\\"DenyToChangePanel\\\": true,\\r\\n  \\\"ShowDescription\\\": true,\\r\\n  \\\"MarketTime\\\": \\\"2025-11-23T11:43:01.0491637\\\",\\r\\n  \\\"UtcTime\\\": \\\"2025-11-23T11:43:01.0493707Z\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Search\\\",\\r\\n  \\\"Panel\\\": \\\"Chart\\\",\\r\\n  \\\"IsVerticalIndicator\\\": false,\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"Locked\\\": false,\\r\\n  \\\"AllowedInteraction\\\": true\\r\\n}\",\r\n  \"SourceType\": \"bars\",\r\n  \"SourceSeriesId\": 0,\r\n  \"DataSeries\": [\r\n    {\r\n      \"Type\": \"ATAS.Indicators.PriceSelectionDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"RenderDataSeries\\\",\\r\\n  \\\"Type\\\": \\\"priceSelection\\\",\\r\\n  \\\"Name\\\": \\\"Price\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    }\r\n  ],\r\n  \"LineSeries\": [],\r\n  \"ShowDescription\": true\r\n}"
          ],
          "Height": 60,
          "Collapsed": false
        },
        {
          "IsNew": true,
          "SerializedIndicators": [
            "{\r\n  \"Type\": \"ATAS.Indicators.Technical.ClusterSearch, ATAS.Indicators.Technical, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7\",\r\n  \"Settings\": \"{\\r\\n  \\\"Type\\\": \\\"delta\\\",\\r\\n  \\\"CalcType\\\": \\\"delta\\\",\\r\\n  \\\"AutoFilter\\\": false,\\r\\n  \\\"MinimumFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": true,\\r\\n    \\\"Value\\\": 250.0\\r\\n  },\\r\\n  \\\"MaximumFilter\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 99999.0\\r\\n  },\\r\\n  \\\"MinAverageTrade\\\": 0.0,\\r\\n  \\\"MaxAverageTrade\\\": 0.0,\\r\\n  \\\"MinPercent\\\": 0.0,\\r\\n  \\\"MaxPercent\\\": 0.0,\\r\\n  \\\"DeltaImbalance\\\": 0.0,\\r\\n  \\\"DeltaFilter\\\": 0.0,\\r\\n  \\\"CandleDir\\\": \\\"any\\\",\\r\\n  \\\"BarsRange\\\": 1,\\r\\n  \\\"PriceRange\\\": 3,\\r\\n  \\\"PipsFromHigh\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 100000000.0\\r\\n  },\\r\\n  \\\"PipsFromLow\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 100000000.0\\r\\n  },\\r\\n  \\\"PriceLoc\\\": \\\"upperWick\\\",\\r\\n  \\\"MinCandleHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MaxCandleHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MinCandleBodyHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"MaxCandleBodyHeight\\\": {\\r\\n    \\\"EnabledVisible\\\": true,\\r\\n    \\\"Enabled\\\": false,\\r\\n    \\\"Value\\\": 1\\r\\n  },\\r\\n  \\\"UseTimeFilter\\\": false,\\r\\n  \\\"TimeFrom\\\": \\\"00:00:00\\\",\\r\\n  \\\"TimeTo\\\": \\\"00:00:00\\\",\\r\\n  \\\"OnlyOneSelectionPerBar\\\": false,\\r\\n  \\\"VisualType\\\": \\\"triangle\\\",\\r\\n  \\\"ClusterColor\\\": \\\"#FFFF1E00\\\",\\r\\n  \\\"VisualObjectsTransparency\\\": 70,\\r\\n  \\\"ShowPriceSelection\\\": false,\\r\\n  \\\"PriceSelectionColor\\\": \\\"#FFFF0000\\\",\\r\\n  \\\"Transparency\\\": 0,\\r\\n  \\\"FixedSizes\\\": false,\\r\\n  \\\"Size\\\": 15,\\r\\n  \\\"MinSize\\\": 15,\\r\\n  \\\"MaxSize\\\": 50,\\r\\n  \\\"UseAlerts\\\": false,\\r\\n  \\\"AlertFile\\\": \\\"alert2\\\",\\r\\n  \\\"AlertColor\\\": \\\"#FF000000\\\",\\r\\n  \\\"Days\\\": 20,\\r\\n  \\\"UsePrevClose\\\": false,\\r\\n  \\\"FullScreenMode\\\": false,\\r\\n  \\\"DenyToChangePanel\\\": true,\\r\\n  \\\"ShowDescription\\\": true,\\r\\n  \\\"MarketTime\\\": \\\"2025-11-23T11:43:01.0758351\\\",\\r\\n  \\\"UtcTime\\\": \\\"2025-11-23T11:43:01.0760434Z\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Search\\\",\\r\\n  \\\"Panel\\\": \\\"Chart\\\",\\r\\n  \\\"IsVerticalIndicator\\\": false,\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"Locked\\\": false,\\r\\n  \\\"AllowedInteraction\\\": true\\r\\n}\",\r\n  \"SourceType\": \"bars\",\r\n  \"SourceSeriesId\": 0,\r\n  \"DataSeries\": [\r\n    {\r\n      \"Type\": \"ATAS.Indicators.PriceSelectionDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"RenderDataSeries\\\",\\r\\n  \\\"Type\\\": \\\"priceSelection\\\",\\r\\n  \\\"Name\\\": \\\"Price\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    }\r\n  ],\r\n  \"LineSeries\": [],\r\n  \"ShowDescription\": true\r\n}"
          ],
          "Height": 60,
          "Collapsed": false
        },
        {
          "IsNew": true,
          "SerializedIndicators": [
            "{\r\n  \"Type\": \"ATAS.Indicators.Technical.ClusterStatistic, ATAS.Indicators.Technical, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7\",\r\n  \"Settings\": \"{\\r\\n  \\\"RowsOrder\\\": {\\r\\n    \\\"Ask\\\": {\\r\\n      \\\"Order\\\": 0,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Bid\\\": {\\r\\n      \\\"Order\\\": 1,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Delta\\\": {\\r\\n      \\\"Order\\\": 2,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"DeltaVolume\\\": {\\r\\n      \\\"Order\\\": 3,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"SessionDelta\\\": {\\r\\n      \\\"Order\\\": 4,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"SessionDeltaVolume\\\": {\\r\\n      \\\"Order\\\": 5,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"MaxDelta\\\": {\\r\\n      \\\"Order\\\": 6,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"MinDelta\\\": {\\r\\n      \\\"Order\\\": 7,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"DeltaChange\\\": {\\r\\n      \\\"Order\\\": 8,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Volume\\\": {\\r\\n      \\\"Order\\\": 9,\\r\\n      \\\"Enabled\\\": true\\r\\n    },\\r\\n    \\\"VolumeSecond\\\": {\\r\\n      \\\"Order\\\": 10,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"SessionVolume\\\": {\\r\\n      \\\"Order\\\": 11,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Trades\\\": {\\r\\n      \\\"Order\\\": 12,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Height\\\": {\\r\\n      \\\"Order\\\": 13,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Time\\\": {\\r\\n      \\\"Order\\\": 14,\\r\\n      \\\"Enabled\\\": false\\r\\n    },\\r\\n    \\\"Duration\\\": {\\r\\n      \\\"Order\\\": 15,\\r\\n      \\\"Enabled\\\": false\\r\\n    }\\r\\n  },\\r\\n  \\\"ShowAsk\\\": false,\\r\\n  \\\"ShowBid\\\": false,\\r\\n  \\\"ShowDelta\\\": true,\\r\\n  \\\"ShowDeltaPerVolume\\\": false,\\r\\n  \\\"ShowSessionDelta\\\": true,\\r\\n  \\\"ShowSessionDeltaPerVolume\\\": false,\\r\\n  \\\"ShowMaximumDelta\\\": false,\\r\\n  \\\"ShowMinimumDelta\\\": false,\\r\\n  \\\"ShowDeltaChange\\\": false,\\r\\n  \\\"ShowVolume\\\": true,\\r\\n  \\\"ShowVolumePerSecond\\\": false,\\r\\n  \\\"ShowSessionVolume\\\": false,\\r\\n  \\\"ShowTicks\\\": false,\\r\\n  \\\"ShowHighLow\\\": false,\\r\\n  \\\"ShowTime\\\": false,\\r\\n  \\\"ShowDuration\\\": false,\\r\\n  \\\"BackGroundColor\\\": \\\"#800F141C\\\",\\r\\n  \\\"BgTransparency\\\": 10,\\r\\n  \\\"GridColor\\\": \\\"#FF21252F\\\",\\r\\n  \\\"VisibleProportion\\\": true,\\r\\n  \\\"VolumeColor\\\": \\\"#FF434651\\\",\\r\\n  \\\"AskColor\\\": \\\"#FF2962FF\\\",\\r\\n  \\\"BidColor\\\": \\\"#FFF71427\\\",\\r\\n  \\\"TextColor\\\": \\\"#FFFFFFFF\\\",\\r\\n  \\\"Font\\\": {\\r\\n    \\\"Size\\\": 9,\\r\\n    \\\"FontFamily\\\": \\\"Arial\\\",\\r\\n    \\\"Bold\\\": false,\\r\\n    \\\"Italic\\\": false,\\r\\n    \\\"Underline\\\": false,\\r\\n    \\\"Strikeout\\\": false\\r\\n  },\\r\\n  \\\"CenterAlign\\\": true,\\r\\n  \\\"HeaderBackground\\\": \\\"#FF787B86\\\",\\r\\n  \\\"HideRowsDescription\\\": false,\\r\\n  \\\"UseVolumeAlert\\\": false,\\r\\n  \\\"VolumeAlertValue\\\": 0.0,\\r\\n  \\\"VolumeAlertFile\\\": \\\"alert1\\\",\\r\\n  \\\"UseDeltaAlert\\\": true,\\r\\n  \\\"DeltaAlertValue\\\": 5.0,\\r\\n  \\\"DeltaAlertFile\\\": \\\"alert1\\\",\\r\\n  \\\"FullScreenMode\\\": false,\\r\\n  \\\"DenyToChangePanel\\\": true,\\r\\n  \\\"ShowDescription\\\": false,\\r\\n  \\\"MarketTime\\\": \\\"2025-11-23T11:43:01.110824\\\",\\r\\n  \\\"UtcTime\\\": \\\"2025-11-23T11:43:01.1110276Z\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Statistic\\\",\\r\\n  \\\"Panel\\\": \\\"1\\\",\\r\\n  \\\"IsVerticalIndicator\\\": false,\\r\\n  \\\"Visible\\\": true,\\r\\n  \\\"Locked\\\": false,\\r\\n  \\\"AllowedInteraction\\\": true\\r\\n}\",\r\n  \"SourceType\": \"bars\",\r\n  \"SourceSeriesId\": 0,\r\n  \"DataSeries\": [\r\n    {\r\n      \"Type\": \"ATAS.Indicators.ValueDataSeries, ATAS.Indicators, Version=7.0.9.455, Culture=neutral, PublicKeyToken=null\",\r\n      \"Settings\": \"{\\r\\n  \\\"Digits\\\": 4,\\r\\n  \\\"StringFormat\\\": \\\"{0:0.####}\\\",\\r\\n  \\\"ShowOnlyNonZeroLabels\\\": false,\\r\\n  \\\"VisualType\\\": \\\"hide\\\",\\r\\n  \\\"Color\\\": \\\"#FFFF5252\\\",\\r\\n  \\\"ValuesColor\\\": \\\"White\\\",\\r\\n  \\\"Width\\\": 1,\\r\\n  \\\"LineDashStyle\\\": \\\"solid\\\",\\r\\n  \\\"ShowZeroValue\\\": true,\\r\\n  \\\"ShowCurrentValue\\\": true,\\r\\n  \\\"ScaleIt\\\": true,\\r\\n  \\\"DrawAbovePrice\\\": true,\\r\\n  \\\"IgnoredByAlerts\\\": false,\\r\\n  \\\"Id\\\": \\\"ClusterStatisticDefaultDataSeries\\\",\\r\\n  \\\"Type\\\": \\\"value\\\",\\r\\n  \\\"Name\\\": \\\"Cluster Statistic\\\",\\r\\n  \\\"DescriptionKey\\\": \\\"VisualizationDescription\\\"\\r\\n}\"\r\n    }\r\n  ],\r\n  \"LineSeries\": [],\r\n  \"ShowDescription\": false\r\n}"
          ],
          "Height": 60,
          "Collapsed": false
        }
      ],
      "Indicators": [],
      "clusterSettings": {
        "Caption": "Cluster Settings",
        "Volumes": "#FF2962FF",
        "Bid": "#FFF71427",
        "Ask": "#FF2962FF",
        "ClusterBorderWidth": 1,
        "Foreground": "#FFABAEB8",
        "AutoSize": true,
        "FontSize": 9.0,
        "CutLongText": true,
        "MinimumClusterWidthToShowText": 40,
        "ValueAreaColor": "#64C8D8FF",
        "ShowValueArea": false,
        "ImbalanceBid": "#FFFF0000",
        "ImbalanceAsk": "#C50000FF",
        "MinimumImbalanceDifference": 0,
        "IgnoreZeroValues": true,
        "ImbalanceVolumeFilter": 0,
        "ImbalanceRate": 200,
        "ShowDirectionMarker": false,
        "DirectionMakerWidth": 0,
        "ClusterBorderPen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2A2E39"
        },
        "BorderColorByDirection": false,
        "SecondClusters": {
          "Caption": "",
          "Enabled": true,
          "ClustersContentModeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersContentModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volume",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ClustersContentMode": "volume",
          "ClustersModeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersVisualModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volumeHistogram",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ClustersMode": "volumeHistogram",
          "UseBorderOfEachPriceLevelFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": false
          },
          "UseBorderOfEachPriceLevel": false,
          "ColorSchemeFilter": {
            "EnumType": "OFT.Controls.Chart.enums.ClustersColorSchemes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volumeProportion",
            "Enabled": true,
            "EnabledVisible": false
          },
          "ColorScheme": "volumeProportion",
          "ClusterBGFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#00FFFFFF"
          },
          "ClusterBG": "#00FFFFFF",
          "VolumeColor": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#FF2962FF"
          },
          "BidColor": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": "#FFFF0000"
          },
          "AskColor": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": "#FF008000"
          },
          "HeatmapType": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 0
          },
          "UpperCutOff": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 20
          },
          "Contrast": {
            "EnabledVisible": false,
            "Enabled": false,
            "Value": 0
          },
          "MaxVolTypeFilter": {
            "EnumType": "Advanced_Time_And_Sales.ClusterSettings+MaxVolSelectionType, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
            "Value": "volume",
            "Enabled": true,
            "EnabledVisible": false
          },
          "MaxVolType": "volume",
          "MaxVolColorFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#00000000"
          },
          "MaxVolColor": "#00000000",
          "MaxVolSelectionWidthFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": 1
          },
          "MaxVolSelectionWidth": 1,
          "MaxVolTextColorFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": "#FFD1D4DC"
          },
          "MaxVolTextColor": "#FFD1D4DC",
          "MaxLevelBoldFilter": {
            "EnabledVisible": false,
            "Enabled": true,
            "Value": true
          },
          "MaxLevelBold": true
        },
        "BorderType": "none",
        "BorderColorByDirectionFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": false
        },
        "ClusterBorderPenFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": {
            "Color": "#FF2A2E39",
            "LineDashStyle": 0,
            "Width": 1
          }
        },
        "ShowDirectionMarkerFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": 0
        },
        "Showtext": true,
        "ForegroundFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFABAEB8"
        },
        "AutoSizeFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "FontSizeFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 9.0
        },
        "Divider": 1.0,
        "CutLongTextFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "MinimumClusterWidthToShowTextFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 40
        },
        "ValueAreaColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#64C8D8FF"
        },
        "ProportionalMode": "bar",
        "ProportionByAllBars": false,
        "GradientRate": 100,
        "CustomProportionValue": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 0.0
        },
        "CustomproportionVolume": 0.0,
        "UpperCutOffGradient": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": 0
        },
        "EnableBidAskImbalance": true,
        "ImbalanceBidFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFFF0000"
        },
        "ImbalanceAskFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#C50000FF"
        },
        "ImbalanceRateFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 200
        },
        "ImbalanceVolumeFilterInt": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 0
        },
        "MinimumImbalanceDifferenceFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 0
        },
        "IgnoreZeroValuesFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "BoldFontForImbalances": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "CustomRowHeight": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": 16
        },
        "Filters": [],
        "ClustersContentModeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersContentModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "delta",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ClustersContentMode": "delta",
        "ClustersModeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersVisualModes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "deltaHistogram",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ClustersMode": "deltaHistogram",
        "UseBorderOfEachPriceLevelFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": false
        },
        "UseBorderOfEachPriceLevel": false,
        "ColorSchemeFilter": {
          "EnumType": "OFT.Controls.Chart.enums.ClustersColorSchemes, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "heatMapDelta",
          "Enabled": true,
          "EnabledVisible": false
        },
        "ColorScheme": "heatMapDelta",
        "ClusterBGFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#00FFFFFF"
        },
        "ClusterBG": "#00FFFFFF",
        "VolumeColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FF2962FF"
        },
        "BidColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FFF71427"
        },
        "AskColor": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "#FF2962FF"
        },
        "HeatmapType": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 10
        },
        "UpperCutOff": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 25
        },
        "Contrast": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 10
        },
        "MaxVolTypeFilter": {
          "EnumType": "Advanced_Time_And_Sales.ClusterSettings+MaxVolSelectionType, OFT.Platform.Core, Version=7.0.9.455, Culture=neutral, PublicKeyToken=330427d8594115c7",
          "Value": "volume",
          "Enabled": true,
          "EnabledVisible": false
        },
        "MaxVolType": "volume",
        "MaxVolColorFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFFFFFFF"
        },
        "MaxVolColor": "#FFFFFFFF",
        "MaxVolSelectionWidthFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": 1
        },
        "MaxVolSelectionWidth": 1,
        "MaxVolTextColorFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": "#FFD1D4DC"
        },
        "MaxVolTextColor": "#FFD1D4DC",
        "MaxLevelBoldFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": true
        },
        "MaxLevelBold": true
      },
      "colorsettings": {
        "BuyCandlePricePen": {
          "Color": "5, 181, 140",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "SellCandlePricePen": {
          "Color": "245, 32, 71",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "BuyBarPricePen": {
          "Color": "8, 153, 129",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "SellBarPricePen": {
          "Color": "242, 56, 90",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "DojiBarPricePen": {
          "Color": "125, 125, 125",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "LineChartPricePen": {
          "Color": "41, 98, 255",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "MountainChartPricePen": {
          "Color": "71, 107, 150",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "SolidCurrentPricePen": {
          "Color": "54, 58, 69",
          "DashStyle": "solid",
          "Width": 1.0
        },
        "Caption": "Chart Color Settings",
        "BackgroundBrushSettings": {
          "UseEndColor": false,
          "StartColor": "#FF0F141C",
          "EndColor": "#FFADD8E6"
        },
        "BackGround": "#FF0F141C",
        "OhlcColor": {
          "EnabledVisible": true,
          "Enabled": true,
          "Value": "#FFABAEB8"
        },
        "StateColor": "#FFABAEB8",
        "TextHistogramColor": "#FFB2B5BE",
        "LabelsBackgroundColor": "#00000000",
        "IndicatorsSeparator": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF434651"
        },
        "CurrentPriceColor": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#FF363A45"
        },
        "PriceLinePen": {
          "LineDashStyle": "dash",
          "Width": 1,
          "Color": "#FFEF5350"
        },
        "PriceLineDashStyle": "solid",
        "PriceLineWidth": 1,
        "ExtendPriceLine": false,
        "CrosshairPen": {
          "LineDashStyle": "dash",
          "Width": 1,
          "Color": "#FF9598A1"
        },
        "AVersion": 1,
        "AxisCurrentBackColor": "#FF363A45",
        "AxisCurrentForeColor": "#FFF1F1F1",
        "GridPen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF21252F"
        },
        "ShowVHorizontalGrid": true,
        "CustomGridStep": 0,
        "ShowVericalGrid": false,
        "CustomVertGridStep": 0,
        "NewSessionPen": {
          "LineDashStyle": "dash",
          "Width": 1,
          "Color": "#00FFFFFF"
        },
        "AxisColorFilter": {
          "EnabledVisible": true,
          "Enabled": true,
          "Value": "#FF151B26"
        },
        "AxisColor": "#FF151B26",
        "AxisTextColor": "#FFABAEB8",
        "FontSizeDecimal": 10.0,
        "TimeFormat": "auto",
        "HidePriceAxis": false,
        "DrawAxisBorders": true,
        "BuyColor": "#FF05B58C",
        "SellColor": "#FFF52047",
        "DrawCandleBorder": false,
        "CandleBorderColorAsBody": true,
        "CellBorderColor": "#FF7D7D7D",
        "CandleBorderWidth": 1,
        "BarsWidth": 1,
        "DojiBarColor": "#FF7D7D7D",
        "DownBarColor": "#FFF2385A",
        "UpBarColor": "#FF089981",
        "ShowOpenOfBar": true,
        "ShowCloseOfBar": true,
        "ChartLinePen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2962FF"
        },
        "MountainLinePen": {
          "LineDashStyle": "solid",
          "Width": 1,
          "Color": "#FF2962FF"
        },
        "MountainBrushSettings": {
          "UseEndColor": true,
          "StartColor": "#B62962FF",
          "EndColor": "#062962FF"
        },
        "UseSessionTime": false,
        "SessionStartFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "00:00:00"
        },
        "SessionStart": "00:00:00",
        "SessionEndFilter": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "23:59:59"
        },
        "SessionEnd": "23:59:59",
        "PriceBorder": false,
        "ShowIndicatorsValuesOnMouseOver": true,
        "AutoTransFormCandles": true,
        "CandleSizeTotransformToClusters": 20,
        "HideClustersPanel": true,
        "AutoTransformHorizontalLines": false,
        "AutoTransformVerticalLines": false,
        "PriceOffset": 80,
        "ChartOffset": 30,
        "UseSmoothing": true,
        "MouseWheelBehavior": "zoom",
        "LeaveRulerOnMouseRelease": false,
        "ShowIndicatorsList": true,
        "MinimizeValues": true,
        "DigitsAfterComma": 0,
        "VolumesInUSDTFilter": {
          "EnabledVisible": false,
          "Enabled": true,
          "Value": false
        },
        "VolumesInUSD": false,
        "KeepSelectedObjects": false,
        "ObjectsSelectionDrawingColor": "30, 83, 228",
        "ObjectsSelectionColor": "#FF1E53E4",
        "Sensitivity": 0,
        "UseOptimizationMode": false,
        "UseCustomUpdateIntervals": false,
        "CustomFPS": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": {
            "Start": 10,
            "End": 50
          }
        },
        "IsChartInstrumentCrypto": true,
        "IndicatorsListIsCollapsed": true,
        "VolumeValuesFormat": "{0:0.}",
        "RedrawInterval": 100,
        "NewSessionLineColor": "#00FFFFFF",
        "Сl_crosshair": "#FF9598A1",
        "GridColor": "#FF21252F",
        "HistogramLinesColor": "#C8ADD8E6",
        "HistogramColor": "#FF808080",
        "ShowCumulativeValues": true,
        "BidColor": "#FFE84548",
        "AskColor": "#FF49D149",
        "ValueAreaColor": "#FFC8D8FF",
        "PocColor": "#FFC8D8FF",
        "HistogramTextColor": "#FF35212E",
        "ExtendPoc": false,
        "ExtendValueArea": false
      },
      "histogramInterval": "contract",
      "typeHistogram": "bidAsk",
      "ShowHistogram": false,
      "ShowingDigital": false,
      "UseOpacility": false,
      "ShowTxtMouse": true,
      "VisibleCrossHair": true,
      "ShowValueArea": true,
      "ShowPoc": true,
      "AlwaysOnTop": false,
      "BarsType": "clusters",
      "ClusterWidth": 130.3182282572290187370032652,
      "TypeCluster": "volume",
      "PaintingMode": "drawCrossHair",
      "TradingSettings": {
        "PnLMode": "money",
        "Caption": "",
        "ShowText": true,
        "OneClickMode": false,
        "TradingMode": "autoDetection",
        "StopMode": "stop",
        "Slippage": 5,
        "ShowTrades": "visible",
        "Size": 6,
        "TradesColor": "#FF2962FF",
        "TradesSellColor": "#FF2962FF",
        "ShowOrders": "visible",
        "OrdersOffset": 115,
        "BuyOrdersColors": "#FF089981",
        "SellOrdersColor": "#FFF2385A",
        "LimitColors": "#FF089981",
        "StopColor": "#FFF2385A",
        "OrderstextColor": "#FFD1D4DC",
        "ShowPosition": "visible",
        "PositionOffset": 115,
        "PositionTextColors": "#FFF1F1F1",
        "PositionBackGround": "#FF151B26",
        "PositionPositive": "#FF089981",
        "PositionNegative": "#FFF2385A",
        "SkipValidateStrategy": false
      },
      "ClusterVisualizationType": "bidAskLadder",
      "Version": 1,
      "ChangeHeightmanualy": true,
      "RowHeight": 7.795506443536393,
      "UseAutoScale": true,
      "LayoutString": "<XtraSerializer version=\"1.0\" application=\"\">\r\n  <property name=\"#LayoutVersion\">1.4</property>\r\n  <property name=\"$BarManager\" iskey=\"true\" value=\"BarManager\">\r\n    <property name=\"RuntimeCustomizations\" iskey=\"true\" value=\"11\">\r\n      <property name=\"Item1\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126548312</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item2\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126548312</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item3\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564203</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item4\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564203</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item5\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">DrawingObjectsToolbar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564218</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item6\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" isnull=\"true\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">126564218</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item7\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">Visible</property>\r\n        <property name=\"NewValue\" type=\"System.Boolean\">false</property>\r\n        <property name=\"OldValue\" type=\"System.Boolean\">true</property>\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">953609</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item8\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBarRight</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">962000</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item9\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ToolBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">962000</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item10\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">DrawingObjectsToolbar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">962031</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n      <property name=\"Item11\" isnull=\"true\" iskey=\"true\">\r\n        <property name=\"PropertyName\">DockInfo.ContainerName</property>\r\n        <property name=\"NewValue\" type=\"System.String\" />\r\n        <property name=\"OldValue\" type=\"System.String\" />\r\n        <property name=\"ActOnHost\">false</property>\r\n        <property name=\"TargetName\">ClusterBar</property>\r\n        <property name=\"Overwrite\">true</property>\r\n        <property name=\"Timestamp\">962031</property>\r\n        <property name=\"CustomizationType\">DevExpress.Xpf.Bars.RuntimePropertyCustomization</property>\r\n        <property name=\"AffectedTargets\" iskey=\"true\" value=\"0\" />\r\n      </property>\r\n    </property>\r\n  </property>\r\n  <property name=\"$BarManager$ChartLayoutControl\" iskey=\"true\" value=\"BarManager$ChartLayoutControl\">\r\n    <property name=\"CollapsableContentWidth\">215</property>\r\n  </property>\r\n</XtraSerializer>",
      "FixedProfile": {
        "Clicks": 0,
        "_color": "128, 41, 98, 255",
        "_valueAreaColor": "120, 123, 134",
        "_maxLevelColor": "209, 212, 220",
        "_textcolor": "171, 174, 184",
        "_linesColor": "120, 123, 134",
        "AutoSetSecondPos": false,
        "_pressedElement": "none",
        "Pressed": false,
        "IsObjectInPanel": false,
        "IsUnderCursor": false,
        "PanelID": 0,
        "_lastScale": 200,
        "Width": 1,
        "ShowLabelsOfFinishedLines": false,
        "AreaOpacility": 0,
        "ShowCumulativeVaues": true,
        "IsFixedMode": true,
        "IsAnchored": false,
        "Offset": 0,
        "ProfileWidth": 0,
        "_areaColor": "0, 255, 255, 255",
        "_borderColor": "30, 83, 228",
        "CustomPeriodIsSet": false,
        "TPOMode": "volumeProfile",
        "ProfilePeriod": "currentDay",
        "MarketProfileTimeFrame": {
          "EnabledVisible": false,
          "Enabled": false,
          "Value": "00:30:00"
        },
        "ProfileLocation": "left",
        "AreaFillColor": "#00FFFFFF",
        "BorderColor": "#FF1E53E4",
        "Type": "volume",
        "ExtendLines": false,
        "ShowValues": true,
        "LeftToRight": true,
        "VisualizationMode": "solid",
        "Gradient": false,
        "GradientFilter": false,
        "WidthFactor": 100,
        "CalculateBasedSelection": false,
        "ProfileColor": "#802962FF",
        "BidColor": "#80F71427",
        "AskColor": "#802962FF",
        "ValuesColor": "#FFABAEB8",
        "ShowMaximumLevel": true,
        "MaxLeveltype": "volume",
        "ExtendMaximumLevel": false,
        "LinesColorFilter": "#FF787B86",
        "LinesColor": "#FF787B86",
        "MaxLevelColorFilter": "#FFD1D4DC",
        "MaxLevelColor": "#FFD1D4DC",
        "ShowMaxLevelValueFilter": false,
        "ShowMaxLevelValue": false,
        "ShowMaxLevelDateFilter": false,
        "ShowMaxLevelDate": false,
        "MaxLevelDescriptionFilter": "vPOC",
        "MaxLevelDescription": "vPOC",
        "ShowValueArea": true,
        "ValueAreaVisualType": "lines",
        "ExtendValueAreaFilter": false,
        "ExtendValueArea": false,
        "ValueAreaColorFilter": "#FF787B86",
        "ValueAreaColor": "#FF787B86",
        "ValueAreTextColorFilter": "#FFD1D4DC",
        "ValueAreTextColor": "#FFD1D4DC",
        "VAHDescriptionFilter": "VAH",
        "VAHDescription": "VAH",
        "VALDescriptionFilter": "VAL",
        "VALDescription": "VAL",
        "ShowDynamicPoc": false,
        "DynamicPocColorFilter": "#FFFF5252",
        "DynamicPocWidthFilter": 3,
        "DynamicPocStyleFilter": {
          "EnumType": "System.Drawing.Drawing2D.DashStyle, System.Drawing.Common, Version=8.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51",
          "Value": "solid",
          "Enabled": false,
          "EnabledVisible": false
        },
        "ShowDynamicPocLabelsFilter": false,
        "DynamicPocTextColorFilter": "#FF363A45",
        "TPOChars": "ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
        "Scale": 1,
        "MarkerLetters": "#FF808080",
        "TPOColorMode": "eachDifferent",
        "Colors": [
          "#FFFF0100",
          "#FFFE1600",
          "#FFFE2B00",
          "#FFFE4101",
          "#FFFE5500",
          "#FFFE6A00",
          "#FFFE7E00",
          "#FFFE9400",
          "#FFFEA900",
          "#FFFDBE00",
          "#FFFCCD01",
          "#FFF7D100",
          "#FFF4D701",
          "#FFEFDD00",
          "#FFEEE200",
          "#FFE9E700",
          "#FFDFEE01",
          "#FFE0F200",
          "#FFFFF700",
          "#FFD9FC00",
          "#FFD0FE05",
          "#FFC4FE0B",
          "#FFB9FE10",
          "#FFADFE19",
          "#FFA2FE1F",
          "#FF96FE23",
          "#FF8CFE2C",
          "#FF81FE31",
          "#FF75FD37",
          "#FF69FE40",
          "#FF5EFA4E",
          "#FF53F65B",
          "#FF48F46C",
          "#FF3BF17A",
          "#FF31EE87",
          "#FF26EA96",
          "#FF1AE7A4",
          "#FF10E4B2",
          "#FF04E1C0"
        ],
        "MinimumLitterWidth": 10,
        "DrawingMode": "auto",
        "BlockTextColor": "#FF000000",
        "TimePeriod": 30,
        "SplitPeriods": false,
        "HighlightColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#FFFF0000"
        },
        "HighlightEveryOpen": false,
        "HighlightColor": "#FFFF0000",
        "HighlightEveryClose": false,
        "HighlightCloseColor": "#FFFF0000",
        "HighlightCloseColorFilter": {
          "EnabledVisible": true,
          "Enabled": false,
          "Value": "#FFFF0000"
        },
        "ShowTPOPoc": true,
        "TPOPocColorFilter": "#FF787B86",
        "TPOPocColor": "#FF787B86",
        "ExtendTPOPocFilter": false,
        "ExtendTPOPoc": false,
        "TPOPOCTextColorFilter": "#FFD1D4DC",
        "TPOPOCTextColor": "#FFD1D4DC",
        "TPOPOCDescriptionFilter": "TPO POC",
        "TPOPOCDescription": "TPO POC",
        "ValueAreaVisualMode": "lines",
        "TPOVAColorFilter": "#FF787B86",
        "TPOVAColor": "#FF787B86",
        "ExtendTPOValueAreaFilter": false,
        "ExtendTPOValueArea": false,
        "TPOValueAreTextColorFilter": "#FFD1D4DC",
        "TPOValueAreTextColor": "#FFD1D4DC",
        "TPOVAHDescriptionFilter": "TPO VAH",
        "TPOVAHDescription": "TPO VAH",
        "TPOVALDescriptionFilter": "TPO VAL",
        "TPOVALDescription": "TPO VAL",
        "ShowSinglePrints": false,
        "ExtendSinglePrintsFilter": false,
        "ExtendSinglePrints": false,
        "SinglePrintsColorFilter": "#FFADD8E6",
        "SinglePrintsColor": "#FFADD8E6",
        "TPOSinglePrintsTextColorFilter": "#FF000000",
        "TPOSinglePrintsTextColor": "#FF000000",
        "ShowInitialBalance": false,
        "InitialBalanceStartPeriodFilter": 1,
        "InitialBalanceStartPeriod": 1,
        "InitialBalanceRangeFilter": 2,
        "InitialBalanceRange": 2,
        "InitialBalanceColorFilter": "#FFFF9800",
        "InitialBalanceColor": "#FFFF9800",
        "InitialBalanceWidthFilter": 5,
        "InitialBalanceWidth": 5,
        "CandleMode": "none",
        "CandleWidthFilter": 16,
        "CandleWidth": 16,
        "BorderFilter": "#FF808080",
        "Border": "#FF808080",
        "BorderWidthFilter": 3,
        "BorderWidth": 3,
        "UpCandleColorFilter": "#FF089981",
        "UpCandleColor": "#FF089981",
        "DnCandleColorFilter": "#FFF2385A",
        "DnCandleColor": "#FFF2385A",
        "SummaryTextColor": "#FFD1D4DC",
        "CumulativeVauesLocation": "bottomRight",
        "ShowBidAsk": false,
        "ShowHighLowPrices": false,
        "BidSummaryColor": "#FFF2385A",
        "AskSummaryColor": "#FF089981",
        "ValuesSummaryColor": "#FFD1D4DC",
        "UseFilter": false,
        "MinDecimalFilter": 0.0,
        "MinFilter": 0.0,
        "MaxDecimalFilter": 0.0,
        "MaxFilter": 0.0,
        "ColorFilter": "#FF311B92",
        "FilterColor": "#FF311B92",
        "FullLineFilter": false,
        "FullLine": false,
        "UsePocAlert": false,
        "PocAlertFile": "alert1",
        "UsePocTouchAlert": false,
        "RepeatPocTouchAlert": false,
        "PocTouchAlertFile": "alert1",
        "UseValAlert": false,
        "RepeatValAlert": false,
        "ValAlertFile": "alert1",
        "UseVahAlert": false,
        "RepeatVahAlert": false,
        "VahAlertFile": "alert1",
        "AreaColor": "#1A3B3BFE",
        "Color": "#FF3B3BFE",
        "Style": "solid",
        "UseApproximationAlert": false,
        "UseRepetitiveAlertFilter": false,
        "UseRepetitiveAlert": false,
        "FilterApproximation": 3,
        "ApproximationFilter": 3,
        "AlertFileFilter": "alert1",
        "AlertFile": "alert1",
        "ShowAlertIconFilter": true,
        "ShowAlertIcon": true,
        "AlertForeColorFilter": "#FFFFFFFF",
        "AlertForeColor": "#FFFFFFFF",
        "AlertBGColorFilter": "#FF000000",
        "AlertBGColor": "#FF000000",
        "FirstPrice": 4421.0,
        "FirstPos": 0,
        "SecondPrice": 4488.0,
        "SecondPos": 0,
        "_firstTime": "0001-01-01T00:00:00",
        "_secondTime": "0001-01-01T00:00:00",
        "Id": "88f14350-c4d9-4fbf-bfe5-388b07610eed",
        "IsGlobal": false,
        "ShowBelowChart": false,
        "Selected": false,
        "MouseOver": false,
        "InstrumentName": "BTCUSDT@Bybit",
        "InstrumentUniqName": "BTCUSDT",
        "UseTimeAxisDrawing": false,
        "Visible": true,
        "Locked": false
      },
      "Minimum": 88484.73434668742011360346628,
      "Maximum": 89716.21302860933610937027490
    },
    "TimeFrame": {
      "Period": "timeFrame",
      "PeriodParameters": {
        "$type": "OFT.Controls.Chart.MinuteTimeFrame, OFT.Controls",
        "TimeFrame": "h4",
        "CustomTimeFrame": 1,
        "Label": "@value",
        "DefaultDaysToLoad": 30,
        "VisualName": "H4"
      },
      "CustomDaysCount": 30,
      "CustomEndDate": "2025-11-23T12:09:19.5542418+01:00",
      "CustomStartDate": "2025-10-25T12:09:19.5542418+01:00",
      "LoadCustomDateSetting": false,
      "CustomDateSetting": "daysCount",
      "IsHistorical": false
    },
    "Canvas": {
      "Elements": []
    },
    "LinkedPanels": [],
    "Width": 130.3182282572290187370032652,
    "StrategySettings": [],
    "TraderSettings": {
      "SelectedTIF": "goodTillCancel",
      "SelectedRoute": "",
      "SelectedOrderType": "market",
      "Volume": 0.0,
      "ApplyToAllWindow": false,
      "IsPercentMode": false,
      "StopPrice": 0.0,
      "StopTriggerPriceType": "none",
      "MarketOrderFlags": {},
      "LimitOrderFlags": {},
      "ConditionalMarketOrderFlags": {},
      "ConditionalLimitOrderFlags": {}
    },
    "IsVisibleDrawingObjectsBar": true,
    "TradingSession": {
      "Id": 1
    },
    "TradingIsLocked": false
  },
  "IsSystem": false
}